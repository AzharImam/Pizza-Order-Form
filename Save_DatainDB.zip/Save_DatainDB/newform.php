<?php 
    if (isset($_POST["submit"])) {
        $name = $_POST["name"];
        $email = $_POST["email"];
        $npswd = $_POST["npass"];
        $cpswd = $_POST["cpass"];
        $gender = $_POST["gender"];
        $country = $_POST["country"];
    }

    if ($npswd == $cpswd) {
        //Connection
        $con =  mysqli_connect("localhost","root","","register");
        //Query
        $insert_query ="INSERT INTO `login_user`(`Name`, `Email`, `Password`, `Gender`, `Country`)
         VALUES ('$name','$email','$npswd','$gender','$country')";
         //Execute
         $execute = mysqli_query($con, $insert_query);

         if ($execute == true) {
            echo "<script>
            alert('Data save successfully');
            window.location.href='newform.html';
            </script>";
         } else {
            echo "<script>alert('".mysqli_error($con)."'); 
            window.location.href='newform.html';
            </script>";
         }
         
    }
    else{
        echo "<script> alert('Password not match');
        window.location.href='newform.html';
        </script>";
    }
?>