<?php
    if(isset($_POST["btn"]))
    {
        $name = $_POST["uname"];
        $email = $_POST["uemail"];
        $upswd = $_POST["upwd"];
        $cpswd = $_POST["cpswd"];
        $gender = $_POST["gender"];
        $country = $_POST["country"];
        if($upswd == $cpswd){
            // Connection
           $con = mysqli_connect("localhost","root","","register");
           // Query
           $insert_query = "INSERT INTO `tbl_usr`(`Name`, `Email`, `Password`, `Gender`, `Country`) 
           VALUES ('$name','$email','$upswd','$gender','$country')";

           $execute = mysqli_query($con, $insert_query );

           if ($execute == true) {
            echo "<script>
                alert('Data Save Successfully');
                window.location.href='form.html';
            </script>";
           } else {
                echo "<script>
                alert('". mysqli_error($con) ."');
                window.location.href='form.html';
            </script>";
           }       }
        else{
            echo "<script>
                alert('Password not Match');
                window.location.href='form.html';
            </script>";
        }

    }
    else{
        header("location: form.html");
    }

?>