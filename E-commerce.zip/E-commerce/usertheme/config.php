<?php
$connect = mysqli_connect('localhost', 'root', '', 'famms');
if (!$connect) {
    die('Could not connect: ' . mysqli_connect_error() ) ;
}
echo 'Connected successfully';

?>