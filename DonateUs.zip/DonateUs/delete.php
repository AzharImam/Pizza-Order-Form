<?php 
    require_once "config.php";
    
    if (isset($_GET["idjao"])) {
        $id = $_GET["idjao"];
        $delete_query = "DELETE FROM `donation_table1` WHERE `Id` = $id";
        $run = mysqli_query($conn , $delete_query);

        if ($run == true) {
            echo '<script>
                alert("Record Deleted");
                window.location.href= "read.php";
            </script>';
        } else {
            echo '<script>
            alert("Something Went Wrong");
            window.location.href= "read.php";
        </script>';
        }
        
    } else {
        header("location: read.php");
    }

    




?>