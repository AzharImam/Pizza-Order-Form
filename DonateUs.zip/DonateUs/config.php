<?php 
   $conn = mysqli_connect("localhost","root","","donation_db");



?>