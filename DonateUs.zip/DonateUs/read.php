<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
<?php
    require_once "config.php";

    $select_query = "SELECT * FROM `donation_table1`";
    $run = mysqli_query($conn, $select_query);
  // Data Show in Cards


   echo '<div class="container"><div class="row">';
  if (mysqli_num_rows($run) != 0) {
   while($kuchbhi = mysqli_fetch_array($run)){
        echo "<div class='col-md-3'>
        <div class='card' style='width: 18rem;'>
  <div class='card-body'>
    <h5 class='card-title'>$kuchbhi[1]  $kuchbhi[2]</h5>
    <p class='card-text'>$kuchbhi[5]</p>
    <a href='#' class='btn btn-primary'>$kuchbhi[5]</a>
  </div>
</div>
        </div>";
   }

  } else {
    echo "<div class='col-md-3'>
        <div class='card' style='width: 18rem;'>
  <div class='card-body'>
    <h5 class='card-title text-danger'>No Record Found</h5>
  
</div>
        </div>
        </div>";
  }
  

echo "</div></div>";





    // Data Show in Table

    echo "<table class='table table-border table-striped table-dark'>
        <tr>
            <td>Id</td>
            <td>First Name</td>
            <td>Mother Name</td>
            <td>Father Name</td>
            <td>Student Email</td>
            <td>Addresss</td>
            <td>Date Of Birth</td>
            <td>Pin Code</td>
            <td>Gender</td>
            <td>University Name</td>
        </tr>";
   
    if (mysqli_num_rows($run) == 0) {
       echo "<tr>
       <td colspan='10' class='text-center text-danger''>No Record Found</td>
       </tr>";
    } else {
        while($abc = mysqli_fetch_assoc($run)){
            echo"<tr>
                <td>" . $abc["Id"] . "</td>
                <td>" . $abc["Name"] ."</td>
                <td>" . $abc["Company"] ."</td>
                <td>". $abc["Email"] ."</td>
                <td>". $abc["Phone_number"] ."</td>
                <td>". $abc["Payment_method"] ."</td>
                <td>". $abc["Cheque_no"] ."</td>
                <td>". $abc["Draw_on"] ."</td>
                <td>". $abc["Payable_at"] ."</td>
            </tr>";
        }
    }
    
echo "</table>
";



?>