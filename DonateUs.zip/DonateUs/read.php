<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Read-PHP</title>
  </head>
  <body>
    <?php
    require_once("config.php");

    $select_query = "SELECT * FROM `donation_table1`";
    $run = mysqli_query($conn, $select_query);


    // Data Show in Card


//    echo '<div class="mt-4 container"><div class="row">';
//   if (mysqli_num_rows($run) != 0) {
//    while($kuchbhi = mysqli_fetch_array($run)){
//         echo "<div class='col-md-3'>
//         <div class='card' style='width: 18rem;'>
// <div class='card-body'>
//     <h4 class='card-title'>$kuchbhi[1]</h4>
//     <h5>$kuchbhi[2]</h5>
//     <p class='card-text'>$kuchbhi[4]</p>
//     <a href='#' class='btn btn-primary'>$kuchbhi[3]</a>
//     <a class='btn btn-danger' href='main.html'><b>Home</b></a>

//   </div>
// </div>
//         </div>";
//    }

//   } else {
//     echo "<div class='col-md-3'>
//         <div class='card' style='width: 18rem;'>
//   <div class='card-body'>
//     <h5 class='card-title text-danger'>No Record Found</h5>

// </div>
//         </div>
//         </div>";
//   }


//     echo "</div></div>";






    // Data Show in Table


    echo '<div class="mt-4 container-fluid">';
    echo "<table class='table table-border table-striped table-warning'>
        <tr>
            <td><b>Id</b></td>
            <td><b>Name</b></td>
            <td><b>Company</b></td>
            <td><b>Email</b></td>
            <td><b>Phone_number</b></td>
            <td><b>Payment_method</b></td>
            <td><b>Cheque_no</b></td>
            <td><b>Draw_on</b></td>
            <td><b>Payable_at</b></td>
        </tr>";
   
    if (mysqli_num_rows($run) == 0) {
       echo "<tr>
       <td colspan='10' class='text-center text-danger''>No Record Found</td>
       </tr>";
    } else {
        while($abc = mysqli_fetch_array($run)){
            echo"<tr>
                <td>$abc[0]</td>
                <td>$abc[1]</td>
                <td>$abc[2]</td>
                <td>$abc[3]</td>
                <td>$abc[4]</td>
                <td>$abc[5]</td>
                <td>$abc[6]</td>
                <td>$abc[7]</td>
                <td>$abc[8]</td>
            </tr>";
        }
    }
    echo "</table>";
    echo '<a class="btn btn-danger" href="main.html"><b>Home</b></a>';
echo '</div>';

?>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>