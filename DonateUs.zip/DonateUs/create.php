<?php
require_once "config.php";

   if(isset($_POST["submit"])){

   $first_name = $_POST["first_name"];
   $last_name = $_POST["last_name"];
   $company = $_POST["company"];
   $email = $_POST["email"];
   $phone_number = $_POST["phone_number"];
   $payment = $_POST["payment"];
   $chequeno = $_POST["chequeno"];
   $bank_name = $_POST["bank_name"];
   $payable = $_POST["payable"];

   $fullname = $first_name ." ".$last_name;

   $insert = "INSERT INTO `donation_table1`(`Name`, `Company`, `Email`, `Phone_number`, `Payment_method`, `Cheque_no`, `Draw_on`, `Payable_at`) VALUES ('$fullname','$company','$email','$phone_number','$payment','$chequeno','$bank_name','$payable')";

    $execute = mysqli_query($conn,$insert);

    if ($execute == true) {
        echo "<script> alert('Data save')
        window.location.href = 'read.php    '
        </script>";   
    } else {
        echo "<script> alert('Error 404')
        window.location.href = 'main.html'
        </script>";
    }   
   }
?>