<?php
    session_start();

    require_once("config.php");

    if (isset($_POST["messbtn"])) {
        $name = $_POST["name"];
        $email = $_POST["email"];
        $message = $_POST["message"];
        $subject = $_POST["subject"];


    } else {
        $insert_query = "INSERT INTO `unique_table`(`User_Name`, `Email`) VALUES ('$_SESSION[username]','$_SESSION[email]')";

        $execute_insert = mysqli_query($connect,$insert_query);

        if ($execute_insert == TRUE) {
            echo '<script>
                alert("User Registerd Successfuly");
                window.location.href="form.html";
            </script>';
        } else {
            echo '<script>
                alert("'. mysqli_error($connect) .'");
                window.location.href="form.html";
            </script>';
        }
    }
    


?>
