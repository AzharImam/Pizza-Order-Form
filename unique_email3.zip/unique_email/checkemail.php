<?php 
    require_once("config.php");

    if (isset($_POST["btn"])) {
        $uname = $_POST["uname"];
        $phone = $_POST["phone"];
        $email = $_POST["email"];
        $pass = $_POST["pass"];

        $check_email_query = "SELECT * FROM `unique_table` WHERE Email = '$email' AND Phone_Number = '$phone' " ;
        $run_check_query = mysqli_query($connect,$check_email_query);
        $kitne_email_he = mysqli_num_rows($run_check_query);

        if ($kitne_email_he > 0  ) {     ?>
            <script>
                alert("Email Already Exist");
                window.location.href="form.html";
            </script>
        
    <?php    
        } else {
            $insert_query = "INSERT INTO `unique_table`(`User_Name`, `Phone_Number`, `Email`, `Password`) VALUES ('$uname','$phone','$email','$pass')";

            $execute_insert = mysqli_query($connect,$insert_query);

            if ($execute_insert == TRUE) {
                echo '<script>
                    alert("User Registerd Successfuly");
                    window.location.href="form.html";
                </script>';
            } else {
                echo '<script>
                    alert("'. mysqli_error($connect) .'");
                    window.location.href="form.html";
                </script>';
            }
            
        }
    

    } else {
        header("location:form.html");
    }
    

?>