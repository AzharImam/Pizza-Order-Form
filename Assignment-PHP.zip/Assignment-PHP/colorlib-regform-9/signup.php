<?php
    require_once "config.php";
    
    if (isset($_POST["submit"])) {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        
        $check_email_query = "SELECT * FROM `sign_up` WHERE Email = '$email' " ;
        $run_check_query = mysqli_query($connect,$check_email_query);
        $kitne_email_hai = mysqli_num_rows($run_check_query);

        if ($kitne_email_hai > 0  ) {     ?>
            <script>
                alert("Email Already Exist");
                window.location.href="index.html";
            </script>
        
    <?php    
        } else {
            $insert_query = "INSERT INTO `sign_up`(`Your_Name`, `Email`, `Password`) VALUES ('$name','$email','$password')";

            $execute_insert = mysqli_query($connect,$insert_query);

            if ($execute_insert == TRUE) {
                echo '<script>
                    alert("User Registerd Successfuly");
                    window.location.href="index.html";
                </script>';
            } else {
                echo '<script>
                    alert("'. mysqli_error($connect) .'");
                    window.location.href="index.html";
                </script>';
            }
            
        }
    

    } else {
        header("location:index.html");
    }
?>