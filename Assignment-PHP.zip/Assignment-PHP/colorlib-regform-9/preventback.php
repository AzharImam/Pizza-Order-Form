<?php 
    require_once "config.php";
    // on login screen, redirect to dashboard if already logged in
    if(isset($_SESSION['login.php'])){
        header('location:welcome.php');
    }
    // on all screens requiring login, redirect if NOT logged in
    if(!isset($_SESSION['id']) && empty($_SESSION['id'])) {
        header('location:login.php');
    }

?>
