<?php 
    require_once "config.php";
   
    // on all screens requiring login, redirect if NOT logged in
    if(!isset($_SESSION['id']) && empty($_SESSION['id'])) {
         header('location:login.php');
    }
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Content</title>

    <!-- <script language="javascript" type="text/javascript">
    window.history.forward();
    </script> -->

</head>
<body>
    <h1>Hello World</h1>
    <p>YouTube. While that may seem like a tough channel to break into, YouTube is still an invaluable way many businesses grow their brand exposure. And with YouTube Shorts, a new micro content form competing with apps like TikTok and Instagram Reels, creators have another avenue to reach audiences in new ways.</p>


    <h1> <?php echo "Welcome ". $_SESSION["username"] ." your Id ".$_SESSION["id"] ; ?> </h1>    

    <a href="logout.php"><input type="button" value="Logout"></a>
</body>
</html>