<?php 
    $connect = mysqli_connect('localhost','root','','batman');
    session_start();

?>