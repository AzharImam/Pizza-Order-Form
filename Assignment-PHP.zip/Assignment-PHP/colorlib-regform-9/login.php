<?php 
    require_once "config.php"; 
    
    if (isset($_POST['submit'])) {
        $email = $_POST['email'];
        $password = $_POST['password'];
        
        $check_login = "SELECT * FROM `sign_up` WHERE Email = '$email' AND Password = '$password'" ;
        $run_login = mysqli_query($connect , $check_login);
        $check_user = mysqli_num_rows($run_login);

        if ($check_user == 0 ) {
            ?>
                <script>
                    alert("Invalid Credentials");
                    window.location.href = "login.html";
                </script>
        <?php
        }
        else {
            $convert_array = mysqli_fetch_array($run_login);
            $_SESSION["username"] = $convert_array[1];
            $_SESSION["id"] = $convert_array[0];
            $_SESSION["email"] = $convert_array[2];
            header("location: welcome.php");
    }
        }

     else {
        header("location:login.html");

    }  

?>