<?php
    if (isset($_POST["btn"])) {
      $fname = $_POST["fname"];
      $lname = $_POST["lname"];
      $uname = $_POST["uname"];
      $email = $_POST["email"];
      $gender = $_POST["gender"];
      $pass = $_POST["pass"];
      $cpass = $_POST["cpass"];
      
      $fullname = $fname ." ".$lname;

   if ($pass == $cpass) {
    //Connection
    require_once "config.php";
    //Query
    $insert_query = "INSERT INTO `panda_table`(`user_name`, `email`, `gender`, `password`) VALUES ('$uname','$email','$gender','$cpass')";
     //Execute
     $execute = mysqli_query($conn, $insert_query);

     if ($execute == true) {
        echo "<script>
        alert('Data save successfully');
        window.location.href='read.php';
        </script>";
     } else {
        echo "<script>alert('".mysqli_error($conn)."'); 
        window.location.href='index.html';
        </script>";
     }
     
    } 
      else{
       echo "<script> alert('Password not match');
       window.location.href='index.html';
      </script>"; 
    }
  }
?>