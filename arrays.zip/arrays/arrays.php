<style>
    table{
        background-color: black;
        
    }
    tr{
        color: whitesmoke;
    }
    td{
        color: red
        ;
    }
    h1{
        color: whitesmoke;
        background-color: blue;
    }
</style>
<?php
//  $myarray = array("potatoes","onion","cabbage","carrot","pumpkin","cucumber","mint","egg plant","tomatoes","string beans","corn");

// //  print_r($myarray);

//  echo"<ul>";
//  for($i = 0; $i < count($myarray); $i++){

//     echo "$i.=>$myarray[$i]<br>";
//  }




//  "</ul>";




// 
// $student = array("enrolnumber" => 1323228,
//                   "name" => "bilal",
//                   "batchcode" => "2107b1",
//                    "fees" => 6000,
//                    "istransferred" => false,
//                    "favcourse" => "php",
//                    "gender" => "MALE"

// );
//   echo"<center><h1>INTRODUCTION</center></h1><br>";
// echo"<center><table border='1'>";
//    foreach ($student as $x => $y) {
  
//     echo "<tr>
    
//      <td color = 'red'>$x</td>
//      <td>$y</td>
    
    
//     </tr>";
//    }                                      
//  echo "</table></center>";

  $movie = [

    "kgf" => [
        "name" => "kgf part1",
        "release" => 2021,
        "hero" => "nh pata",
    ],

    "kgf2" => [
        "name" => "kgf part2",
        "release" => 2021-22,
        "hero" => "iska bhi nh pata ",
    ],
    
   

];
    echo $movie["kgf"]["name"];












//   ]
?>