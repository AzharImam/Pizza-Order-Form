<?php 

    $firstarray = array("Hitman","AC Unity","AC Origin","AC BlackFlag","SP Blacklist","Needforspeed","FIFA","Battlefield","Callofduty");

    print_r($firstarray);
    
    echo  "<ul>";

    for ($i=0; $i < ($firstarray) ; $i++) { 
        echo "$i => $firstarray[$i] <br>";
    }

    echo "</ul>";


?>