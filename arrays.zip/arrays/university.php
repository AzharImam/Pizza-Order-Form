<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>University Array</title>
  </head>
  <body class="container-fluid">

<?php 
    $uni =  
    [
        "index_1"  => [
            "name" => "NED University",
            "logo" => "https://t4.ftcdn.net/jpg/03/11/04/35/360_F_311043597_yg5Y7sxhDlST8GRAKt4FC8VsKsxlfC6U.jpg",
            "phone" => 1020,
            "address" => "Korangi",
            "degree" => ["BS" , "MBA"],
            "no" => 1
        ],

        "index_2"  => [
            "name" => "Karachi University",
            "logo" => "https://t4.ftcdn.net/jpg/04/91/76/63/360_F_491766344_Ei620Y71QdATzR00ubhGu3AGvUhKfFPa.jpg",
            "phone" => 310,
            "address" => "Baldia",
            "degree" => ["phD" , "BBA"],
            "no" => 2
        ],

        "index_3"  => [
            "name" => "Kasbit University",
            "logo" => "https://img.freepik.com/premium-vector/campus-collage-university-education-logo-design-template_7492-63.jpg?w=360",
            "phone" => 223190,
            "address" => "North Karachi",
            "degree" => ["MS" , "MBA"],
            "no" => 3
        ],

        "index_4"  => [
            "name" => "Bhutto University",
            "logo" => "https://t4.ftcdn.net/jpg/02/92/64/19/360_F_292641965_LeZzjp0GaGHixxRMBYQwJjskL1M5DPHO.jpg",
            "phone" => 15,
            "address" => "Lyari",
            "degree" => ["MSC" , "BA"],
            "no" => 4
        ]
    ]   ;
?>

        <div class="row">
            <?php   foreach ($uni as $a => $b) {  ?>
                <div class="card mt-4 col-3" style="width: 18rem;">
                    <img class="card-img-top" src="<?php   echo "$b[logo]"; ?>" alt="Card image cap">

                    <div class="card-body">
                        <h3 class="card-title"> <?php echo "<b>$b[name]</b>"; ?> </h3>
                        <p class="card-text"> <?php   echo "<h4><u>$b[address]</u></h4>"; ?> </p>
                        <p class="card-text"> <?php foreach ($b["degree"] as $degarray) {
                            echo " $degarray";
                        }?> </p>
                        <p class="card-text"> <?php   echo "<h5>$b[phone]</h5>"; ?> </p>
                    </div>
                </div>
            <?php   }  ?>
        </div>
        
        <br><br><br><br><br>
        
        <table class="table">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Image</th>
      <th scope="col">Name</th>
      <th scope="col">Address</th>
      <th scope="col">Degree</th>
      <th scope="col">Phone</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach ($uni as $a => $b) {  ?>
    <tr>
        <th scope="row"><?php   echo "$b[no]"; ?></th>
        <td><img style="width: 135px; height: auto; " src="<?php   echo "$b[logo]"; ?>"></td>
        <td><?php  echo "$b[name]"; ?></td>
        <td><?php  echo "$b[address]"; ?></td>
        <td><?php foreach ($b["degree"] as $degarray) {
                            echo " $degarray";
                        }?> </td>
        <td><?php  echo "$b[phone]"; ?></td>
                
    <?php } ?>
  </tbody>
</table>




    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>