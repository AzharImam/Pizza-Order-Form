<?php 
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Form</title>
</head>
<body class="container-fluid">
    <div class="text-center">
        <br><br>
        <form action="" method="post">
            <label for="n">Name</label>
            <input type="text" name="n" required>
            <br><br>
            <label for="e">Email</label>
            <input type="email" name="e" required>
            <br><br>
            <label for="p">Password</label>
            <input type="password" name="p" required>
            <br><br>
            <input type="submit" value="Submit" name="submit"> 
        </form>
    </div>
    <?php 
    if (isset($_POST["submit"])) {
        $_SESSION["name"] = $_POST["n"];
        $_SESSION["email"] = $_POST["e"];
        $_SESSION["pswd"] = $_POST["p"];
        $_SESSION["regtime"] = time();

        header("location:login.php");
    }
?>

</body>
</html>