<?php 
    session_start();

        if (!isset($_SESSION["email"]) && !isset($_SESSION["pswd"])) {
        header("location: form.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Login</title>
</head>
<body>
<body class="container-fluid">
    <div class="text-center">
        <br><br>
        <form action="" method="post">
            <label for="e">Email</label>
            <input type="email" name="e" required>
            <br><br>
            <label for="p">Password</label>
            <input type="password" name="p" required>
            <br><br>
            <input type="submit" value="Submit" name="submit"> 
        </form>
    </div>
<?php 
    if (isset($_POST["submit"])) {
        $email =$_POST["e"];
        $pswd =$_POST["p"];

        if ($email == $_SESSION["email"] && $pswd == $_SESSION["pswd"]) {
            header("location:dashboard.php");
        } else {
            echo "<script> alert('Invalid credentials') </script>";
        }
        
    }
?>
</body>
</html>