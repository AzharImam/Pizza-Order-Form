<?php 
    session_start();

    //$_SESSION["name"] == null
    if (!isset($_SESSION["name"])) {
        header("location: form.php");
    }

    if ((time() - $_SESSION["regtime"]) > 10) {
        echo "<script> alert ('Session time out get lost'); window.location.href = 'logout.php'  </script>";
       // header("location: logout.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<body>
    <div>
        <p>Welcome <?php echo $_SESSION["name"] ?></p>
        <button><a href="logout.php">logout</a></button>
        <button><a href="">Faltu ka button</a></button>
    </div>
</body>
</html>